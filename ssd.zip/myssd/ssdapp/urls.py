from django.conf.urls import url
from ssdapp import views
from django.views.static import serve

urlpatterns = [
    url(r'^search-form', views.search_form),
    url(r'^search', views.search),
    url(r'^search-traffic', views.search_traffic),
    url(r'^result_image/(?P<path>.*)', serve, {'document_root': '/usr/src/result_image'}),
    url('',  views.search_form),
]
